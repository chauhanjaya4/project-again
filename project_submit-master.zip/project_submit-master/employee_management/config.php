<?php

$con=mysqli_connect('localhost','root','','employee_management');
//$result = mysqli_select_db($conf,'myledger_db');

?>